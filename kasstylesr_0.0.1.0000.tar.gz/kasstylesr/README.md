# kasstylesr

# Set up
Bring the R scripts into your local repository using the command line and git:
In the terminal, navigate to the directory you would like kasstylesr to be saved in e.g. projects
```
cd projects
```
Download kasstylesr into that directory (projects/kasstylesr will be created)
```
git clone https://dev.azure.com/WGDataScience/OpenDataScienceToolsWG/_git/kasstylesr
```
### R packages
The R packages used by kasstylesr are the following:
* ggplot2
* ggExtra
* openxlsx

The package vignette and example script example_script.r require no additional packages

### kasstylesr has 4 main fuctions which can be used seperately or all together
Use color_picker.r to load in the KAS colour themes in the correct order 
* add "+ color_picker(columns)" to your plots

Use kas_style.r to add the KAS style theme
* add "+ kas_style" to your plots

Automate moving all your R chart objects into a folder 
* using the function save_list_of_charts_to_folder()

Automate moving charts from the charts folder into a publication-ready excel workbook 
* using the function chart_folder_to_workbook()

Follow along with the package vignette to follow how kasstylesr can be used to build a KAS-relevant workbook of charts
* The vignette is available by writing browseVignettes("kasstylesr") into the console
